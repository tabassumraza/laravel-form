<?php if (isset($component)) { $__componentOriginal91fdd17964e43374ae18c674f95cdaa3 = $component; } ?>
<?php $component = App\View\Components\AdminLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AdminLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
</style>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            <?php echo e(__('Admin Dashboard')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900 dark:text-gray-100">
                    <?php echo e(__("You're logged in!")); ?>

                </div>
            </div>
        </div>
        <br>
<h2>List of complaints</h2>
<div class="table-responsive">
<table border="1" class="table table-striped table-hover table-condensed ">
    <thead>
      <tr>
        <th><strong>Firstname</strong></th>
        <th><strong>Lastname</strong></th>
        <th><strong>City</strong></th>
        <th><strong>Region</strong></th>
        <th><strong>Postal code</strong></th>
        <th><strong>Country</strong></th>
        <th><strong>Email</strong></th>
        <th><strong>Phone</strong></th>
        <th><strong>Date</strong></th>
        <th><strong>Problem type</strong></th>
        <th><strong>On behalf of</strong></th>

        <th><strong>complaint</strong></th>


        
      </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $complaintforms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>    
      <th><?php echo e($data->fname); ?></th>
      <th><?php echo e($data->lname); ?></th>
      <th><?php echo e($data->cityname); ?></th>
      <th><?php echo e($data->regionname); ?></th>
      <th><?php echo e($data->postal); ?></th>
      <th><?php echo e($data->country); ?></th>
      <th><?php echo e($data->email); ?></th>
      <th><?php echo e($data->phone); ?></th>
      <th><?php echo e($data->date); ?></th>
      <th><?php echo e($data->typeOFproblem); ?></th>
      <th><?php echo e($data->onBehalfof); ?></th>
      <th><?php echo e($data->complain); ?></th>

      
                    
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
</div>    
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $component = $__componentOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\laravel\complain\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>